"""Pure presentation helpers for the HABEAS UI (Phase 8.5).

No Streamlit import, no I/O, no re-derivation of backend conclusions: these
functions only *format* values that a real result object already produced.
The two substantive transformations are:

- ``graph_from_evidence`` — builds the account-graph view strictly from the
  evidence the investigation recorded (cycle legs/events from ``detect_cycle``,
  leg events from ``trace_funds``). No synthetic nodes or edges are ever
  invented, structural connectivity stays visually distinct from chronological
  circulation, and truncation is carried through as a first-class flag;
- ``to_dot`` — bounded DOT rendering (node/edge caps, honest cap notice) for
  ``st.graphviz_chart``, which renders it client-side without a new dependency.
"""
from __future__ import annotations

from typing import Any

from src.agent.policy import (
    VERDICT_INCOMPLETE_INVESTIGATION,
    VERDICT_INSUFFICIENT_EVIDENCE,
    VERDICT_LIKELY_BENIGN,
    VERDICT_SUSPICION_SUPPORTED_FOR_REVIEW,
    VERDICT_SUSPICIOUS_REQUIRES_INVESTIGATION,
)

# Tone vocabulary shared with app.py's CSS (and asserted by tests): every
# status maps to exactly one tone so supported / contradicted / open /
# inconclusive stay visually consistent everywhere.
TONES = ("positive", "watch", "ok", "abstain", "error", "muted")

_VERDICT_CHIPS = {
    VERDICT_SUSPICION_SUPPORTED_FOR_REVIEW: ("Supported for review", "positive"),
    VERDICT_SUSPICIOUS_REQUIRES_INVESTIGATION: ("Suspicious — unconfirmed", "watch"),
    VERDICT_LIKELY_BENIGN: ("Likely benign", "ok"),
    VERDICT_INSUFFICIENT_EVIDENCE: ("Insufficient evidence", "abstain"),
    VERDICT_INCOMPLETE_INVESTIGATION: ("Incomplete investigation", "abstain"),
}

_ACTION_CHIPS = {
    "applied": ("Freeze applied (sandbox)", "positive"),
    "declined": ("Declined by policy", "abstain"),
    "already_applied": ("Already applied earlier", "muted"),
    "in_progress": ("In progress elsewhere", "watch"),
}

_HYPOTHESIS_CHIPS = {
    "supported": ("Supported", "positive"),
    "contradicted": ("Contradicted", "error"),
    "weakened": ("Weakened", "watch"),
    "open": ("Open / untested", "muted"),
    "insufficient": ("Insufficient evidence", "abstain"),
}

_STANCE_CHIPS = {
    "supporting": ("Supports", "positive"),
    "contradicting": ("Contradicts", "error"),
    "unresolved": ("Unresolved", "muted"),
}

# Verification status → (short label, tone). Mismatch is the only failure.
_VERIFICATION_CHIPS = {
    "reproduced_current_state": ("Reproduced", "positive"),
    "verified_against_recorded_evidence": ("Verified vs record", "positive"),
    "changed_after_action": ("Changed after action", "watch"),
    "mismatch": ("Mismatch", "error"),
    "unverifiable": ("Unverifiable", "abstain"),
    "skipped": ("Skipped", "muted"),
}


def verdict_chip(verdict: str | None) -> tuple[str, str]:
    if verdict in _VERDICT_CHIPS:
        return _VERDICT_CHIPS[verdict]
    return ("No verdict", "abstain")


def action_chip(action_status: str | None) -> tuple[str, str]:
    if action_status in _ACTION_CHIPS:
        return _ACTION_CHIPS[action_status]
    if not action_status:
        return ("No action attempted", "muted")
    return (str(action_status), "watch")


def hypothesis_chip(status: str) -> tuple[str, str]:
    return _HYPOTHESIS_CHIPS.get(status, (status or "unknown", "muted"))


def stance_chip(stance: str) -> tuple[str, str]:
    return _STANCE_CHIPS.get(stance, (stance or "unknown", "muted"))


def verification_chip(status: str) -> tuple[str, str]:
    return _VERIFICATION_CHIPS.get(status, (status or "unknown", "watch"))


def run_status_chip(snapshot: dict[str, Any]) -> tuple[str, str]:
    """Top-level run state: green only for a real, completed investigation."""
    if snapshot.get("status") == "configuration_error":
        return ("Provider not configured", "error")
    if snapshot.get("status") == "failed":
        return ("Investigation failed", "error")
    if snapshot.get("status") != "ok":
        return ("No investigation run yet", "muted")
    if not snapshot.get("completed"):
        return ("Investigation incomplete", "watch")
    return ("Investigation completed", "positive")


def verification_counts(summary: dict[str, Any] | None) -> dict[str, int]:
    """Normalized claim-verification counts (missing statuses count as 0)."""
    summary = summary or {}
    return {
        "reproduced": int(summary.get("reproduced_current_state", 0) or 0)
        + int(summary.get("verified_against_recorded_evidence", 0) or 0),
        "changed_after_action": int(summary.get("changed_after_action", 0) or 0),
        "mismatch": int(summary.get("mismatch", 0) or 0),
        "unverifiable": int(summary.get("unverifiable", 0) or 0),
    }


# ------------------------------------------------------------- graph view


MAX_GRAPH_NODES = 40
MAX_GRAPH_EDGES = 80
MAX_TXN_PER_EDGE = 2


def _add_edge(
    edges: dict[tuple[str, str], dict[str, Any]],
    src: str,
    dst: str,
    *,
    kind: str,
    corroborated: bool | None = None,
    txn_id: str | None = None,
    ts: str | None = None,
) -> None:
    key = (src, dst)
    edge = edges.setdefault(
        key,
        {
            "src": src, "dst": dst, "kind": kind,
            "corroborated": corroborated, "txn_ids": [], "timestamps": [],
        },
    )
    if kind == "cycle":
        # Corroboration is the stronger recorded fact and is sticky: if any
        # recorded cycle leg/event for this pair was chronologically
        # corroborated, the edge is corroborated; otherwise it stays
        # structural-only.
        if corroborated:
            edge["corroborated"] = True
        elif edge["corroborated"] is None:
            edge["corroborated"] = False
    if txn_id and txn_id not in edge["txn_ids"] and len(edge["txn_ids"]) < 6:
        edge["txn_ids"].append(txn_id)
    if ts and ts not in edge["timestamps"]:
        edge["timestamps"].append(ts)


def graph_from_evidence(
    evidence_entries: list[dict[str, Any]],
    primary_entities: list[str] | None = None,
) -> dict[str, Any]:
    """Build the graph view from recorded evidence only.

    Nodes/edges come from ``detect_cycle`` derived cycles (legs + timestamped
    events, with the cycle's corroboration flag) and ``trace_funds`` derived
    leg events. Structural-only cycle legs are kept but flagged, so structure
    is never presented as chronological circulation.
    """
    primary = {e for e in (primary_entities or []) if e}
    nodes: dict[str, dict[str, Any]] = {}
    edges: dict[tuple[str, str], dict[str, Any]] = {}
    truncated = False
    notes: list[str] = []

    def touch(account: str, kind: str = "account") -> None:
        if not account:
            return
        node = nodes.setdefault(account, {"id": account, "kind": "account"})
        if account in primary:
            node["kind"] = "primary"

    for entry in evidence_entries or []:
        derived = entry.get("derived") or {}
        if any(entry.get("truncated") or []):
            truncated = True
        if derived.get("truncated"):
            truncated = True

        for cycle in derived.get("cycles") or []:
            corroborated = bool(cycle.get("temporally_corroborated"))
            for leg in cycle.get("legs") or []:
                src, dst = leg.get("src"), leg.get("dst")
                touch(src), touch(dst)
                _add_edge(edges, src, dst, kind="cycle", corroborated=corroborated)
            for evt in cycle.get("events") or []:
                touch(evt.get("src")), touch(evt.get("dst"))
                _add_edge(
                    edges, evt.get("src"), evt.get("dst"), kind="cycle",
                    corroborated=corroborated,
                    txn_id=evt.get("txn_id"), ts=evt.get("ts"),
                )

        for evt in derived.get("leg_events") or []:
            touch(evt.get("src")), touch(evt.get("dst"))
            _add_edge(
                edges, evt.get("src"), evt.get("dst"), kind="traced",
                txn_id=evt.get("txn_id"), ts=evt.get("ts"),
            )

    edge_list = sorted(edges.values(), key=lambda e: (e["src"], e["dst"]))
    capped = len(edge_list) > MAX_GRAPH_EDGES or len(nodes) > MAX_GRAPH_NODES
    if capped:
        notes.append(
            f"graph view capped at {MAX_GRAPH_NODES} nodes / {MAX_GRAPH_EDGES} "
            "edges (bounded rendering; the evidence ledger is authoritative)"
        )
        edge_list = edge_list[:MAX_GRAPH_EDGES]
        kept = {e["src"] for e in edge_list} | {e["dst"] for e in edge_list}
        nodes = {k: v for k, v in nodes.items() if k in kept}
    structural_only = [e for e in edge_list if e["kind"] == "cycle" and not e["corroborated"]]
    if structural_only:
        notes.append(
            f"{len(structural_only)} cycle leg(s) shown dashed: structural "
            "connectivity only, NOT chronological circulation"
        )
    if truncated:
        notes.append(
            "some underlying query results were truncated; the graph may be "
            "incomplete (see the evidence inspector)"
        )
    return {
        "nodes": sorted(nodes.values(), key=lambda n: n["id"]),
        "edges": edge_list,
        "truncated": truncated,
        "capped": capped,
        "notes": notes,
        "has_content": bool(edge_list),
    }


_DOT_COLORS = {
    "bg": "#0f1b2d", "node": "#1c2b45", "node_border": "#3f5f8a",
    "primary": "#14b8a6", "text": "#dbe7f4",
    "cycle_ok": "#14b8a6",       # teal: chronologically corroborated leg
    "cycle_struct": "#64748b",   # slate dashed: structure only
    "traced": "#38bdf8",         # cyan dotted: traced transfer leg
}


def to_dot(graph: dict[str, Any]) -> str:
    """Render the bounded graph view as a DOT string (dark theme)."""
    c = _DOT_COLORS
    lines = [
        "digraph HABEAS {",
        '  bgcolor="transparent";',
        "  rankdir=LR;",
        f'  node [shape=box style="rounded,filled" fillcolor="{c["node"]}" '
        f'color="{c["node_border"]}" fontcolor="{c["text"]}" '
        'fontsize=11 margin="0.12,0.08"];',
        f'  edge [fontcolor="{c["text"]}" fontsize=9];',
    ]
    for node in graph.get("nodes") or []:
        nid = node["id"]
        if node.get("kind") == "primary":
            lines.append(
                f'  "{nid}" [color="{c["primary"]}" penwidth=2 '
                f'fontcolor="{c["primary"]}"];'
            )
        else:
            lines.append(f'  "{nid}";')
    for edge in graph.get("edges") or []:
        attrs: list[str] = []
        if edge["kind"] == "cycle":
            if edge.get("corroborated"):
                attrs += [f'color="{c["cycle_ok"]}"', 'penwidth=2',
                          'label="circulated"']
            else:
                attrs += [
                    f'color="{c["cycle_struct"]}"', 'style=dashed',
                    'label="structure only"',
                ]
        else:
            txns = edge.get("txn_ids") or []
            stamps = edge.get("timestamps") or []
            label_parts = []
            if txns:
                shown = ", ".join(txns[:MAX_TXN_PER_EDGE])
                more = len(txns) - MAX_TXN_PER_EDGE
                label_parts.append(shown + (f" +{more}" if more > 0 else ""))
            if stamps:
                label_parts.append(str(stamps[0]))
            attrs += [
                f'color="{c["traced"]}"', 'style=dotted',
                f'label="{ " · ".join(label_parts) }"' if label_parts else "",
            ]
        attr_text = " ".join(a for a in attrs if a)
        lines.append(
            f'  "{edge["src"]}" -> "{edge["dst"]}"'
            + (f" [{attr_text}]" if attr_text else "") + ";"
        )
    lines.append("}")
    return "\n".join(lines)


# ------------------------------------------------------- evidence inspector


def evidence_inspector_rows(
    evidence_entries: list[dict[str, Any]],
    verification_claims: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """One row per evidence record: all queries, stance, verification."""
    by_id = {c.get("evidence_id"): c for c in (verification_claims or [])}
    rows = []
    for entry in evidence_entries or []:
        claim = by_id.get(entry.get("evidence_id")) or {}
        query_ids = list(entry.get("query_ids") or [])
        row_counts = list(entry.get("row_count") or [])
        rows.append(
            {
                "evidence_id": entry.get("evidence_id"),
                "tool": entry.get("tool"),
                "ok": bool(entry.get("ok")),
                "stance": entry.get("stance"),
                "query_ids": query_ids,
                "query_count": len(query_ids),
                "multi_query": len(query_ids) > 1,
                "total_rows": sum(int(r or 0) for r in row_counts),
                "truncated_any": any(entry.get("truncated") or []),
                "verification_status": claim.get("status") or "not_checked",
                "verification_reason": claim.get("reason") or "",
                "checked_source_queries": claim.get("checked_source_queries") or [],
                "mismatched_source_queries": claim.get("mismatched_source_queries") or [],
                "interpretation": entry.get("interpretation") or "",
            }
        )
    return rows


# ------------------------------------------------------------- run summary


def summarize_run(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Compact metric-card view of one run (safe on failed snapshots)."""
    action = snapshot.get("action") or {}
    return {
        "status": snapshot.get("status"),
        "verdict": snapshot.get("canonical_verdict"),
        "tool_calls": snapshot.get("tool_calls") or 0,
        "tool_budget": snapshot.get("tool_budget"),
        "evidence_count": len(snapshot.get("evidence") or []),
        "signal_families": list(snapshot.get("signal_families") or []),
        "distinct_provenance_families": list(
            action.get("distinct_provenance_families") or []
        ),
        "completed": bool(snapshot.get("completed")),
        "termination_reason": snapshot.get("termination_reason"),
        "errors": list(snapshot.get("errors") or []),
        "truncated_evidence": list(snapshot.get("truncated_evidence") or []),
        "hypotheses_open": sum(
            1 for h in snapshot.get("hypotheses") or []
            if h.get("status") in ("open", "insufficient")
        ),
    }


def is_stale(run: dict[str, Any] | None, selected_alert: str) -> bool:
    """True when a stored run belongs to a different alert than selected."""
    if not run:
        return False
    return run.get("alert_id") != selected_alert


# ------------------------------------------------- neighbourhood + evidence


def merge_graphs(
    neighborhood: dict[str, Any],
    evidence_graph: dict[str, Any],
    *,
    focal: str | None = None,
) -> dict[str, Any]:
    """Combine the MCP neighbourhood rows with the investigation's evidence graph.

    The neighbourhood contributes the accounts and the real aggregate edges
    (with their active flag); the investigation contributes the cycle legs and
    their corroboration flags. Neither side invents anything, and evidence-only
    nodes are kept so an investigated path is always visible.
    """
    accounts: list[str] = []
    for value in (neighborhood.get("accounts") or []):
        if value and value not in accounts:
            accounts.append(value)
    for node in (evidence_graph.get("nodes") or []):
        value = node.get("id")
        if value and value not in accounts:
            accounts.append(value)

    edges: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for edge in (neighborhood.get("edges") or []):
        key = (edge.get("src"), edge.get("dst"))
        if key in seen:
            continue
        seen.add(key)
        edges.append({
            "src": edge.get("src"), "dst": edge.get("dst"),
            "count": edge.get("count"), "total_amount": edge.get("total_amount"),
            "last_ts": edge.get("last_ts"), "active": edge.get("active"),
            "source": "neighborhood",
        })

    cycle_edges: list[dict[str, Any]] = []
    for edge in (evidence_graph.get("edges") or []):
        if edge.get("kind") != "cycle":
            continue
        cycle_edges.append({
            "src": edge.get("src"), "dst": edge.get("dst"),
            "corroborated": bool(edge.get("corroborated")),
        })
        key = (edge.get("src"), edge.get("dst"))
        if key not in seen:
            seen.add(key)
            edges.append({
                "src": edge.get("src"), "dst": edge.get("dst"),
                "count": len(edge.get("txn_ids") or []),
                "total_amount": None,
                "last_ts": (edge.get("timestamps") or [None])[0],
                "active": None, "source": "evidence",
            })

    notes: list[str] = []
    if neighborhood.get("truncated") or evidence_graph.get("truncated"):
        notes.append("one or more queries were truncated — this view may be "
                     "incomplete")
    if neighborhood.get("interpretation"):
        notes.append(neighborhood["interpretation"])
    notes.extend(evidence_graph.get("notes") or [])
    return {
        "accounts": accounts,
        "edges": edges,
        "cycle_edges": cycle_edges,
        "focal": focal or neighborhood.get("focal_account_id"),
        "notes": [n for n in notes if n],
        "truncated": bool(neighborhood.get("truncated")
                          or evidence_graph.get("truncated")),
    }
