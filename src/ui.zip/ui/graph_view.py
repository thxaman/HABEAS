"""Plotly graph rendering for the HABEAS UI (Phase 8.5).

Turns the neighbourhood/evidence rows returned by the backend into a directed
account graph. Every node and edge here comes from a real query result — the
builder never invents a node or an edge to fill a gap.

Design decisions:

- **layout** uses ``networkx.spring_layout`` with a fixed seed, so the same
  graph always renders in the same place (deterministic for a demo, and
  testable);
- **selection**: nodes and edges are separate Plotly traces carrying a
  ``customdata`` key. Streamlit's ``on_select="rerun"`` returns the clicked
  point; :func:`selected_from_event` maps it back to its real record;
- **encoding** never relies on colour alone — active and deactivated edges
  differ in dash pattern *and* label, corroborated circulation is solid with a
  text label, structural-only cycles are dashed and labelled "structure only".

No Streamlit import here: the plotly figure and the selection parser are pure
and unit-tested directly.
"""
from __future__ import annotations

from typing import Any

import networkx as nx

_COLORS = {
    "bg": "#0b1424",
    "focal": "#14b8a6",        # teal — the alerted account
    "account": "#2f4a70",      # slate blue
    "primary": "#38bdf8",      # cyan — investigated entities
    "corroborated": "#2dd4bf",  # teal solid
    "structural": "#94a3b8",    # slate dashed
    "active": "#38bdf8",        # cyan solid
    "inactive": "#f59e0b",      # amber dashed
    "font": "#dbe7f4",
}


def _layout(nodes: list[str], edges: list[tuple[str, str]]) -> dict[str, tuple[float, float]]:
    graph = nx.DiGraph()
    graph.add_nodes_from(nodes)
    graph.add_edges_from((s, d) for s, d in edges)
    if not nodes:
        return {}
    if len(nodes) == 1:
        return {nodes[0]: (0.0, 0.0)}
    # seed fixed so a given graph always lays out identically
    return nx.spring_layout(graph, seed=7, k=None, iterations=60)


def build_figure(
    *,
    accounts: list[str],
    edges: list[dict[str, Any]],
    focal_account_id: str | None = None,
    primary_entities: list[str] | None = None,
    cycle_edges: list[dict[str, Any]] | None = None,
    height: int = 470,
):
    """Build the Plotly figure. Returns ``None`` for an empty graph."""
    import plotly.graph_objects as go

    accounts = [a for a in dict.fromkeys(accounts or []) if a]
    edges = list(edges or [])
    if not accounts:
        return None
    primary = set(primary_entities or [])
    fig = go.Figure()

    edge_keys = [(e["src"], e["dst"]) for e in edges if e.get("src") and e.get("dst")]
    pos = _layout(accounts, edge_keys)

    # ---- edges -----------------------------------------------------------
    # Grouped into three visually distinct traces so the legend explains the
    # semantics (and so the meaning survives without colour).
    corroborated = {
        (c["src"], c["dst"]) for c in (cycle_edges or [])
        if c.get("corroborated") and c.get("src") and c.get("dst")
    }
    structural = {
        (c["src"], c["dst"]) for c in (cycle_edges or [])
        if not c.get("corroborated") and c.get("src") and c.get("dst")
    }

    def add_edges(trace_edges, name, color, dash, show_legend=True):
        xs: list[float | None] = []
        ys: list[float | None] = []
        texts: list[str] = []
        custom: list[list[Any]] = []
        for e in trace_edges:
            src, dst = e.get("src"), e.get("dst")
            if src not in pos or dst not in pos:
                continue
            x0, y0 = pos[src]
            x1, y1 = pos[dst]
            xs += [x0, x1, None]
            ys += [y0, y1, None]
            texts.append(str(e.get("label") or ""))
            custom.append(["edge", src, dst])
        if not xs:
            return
        fig.add_trace(
            go.Scatter(
                x=xs, y=ys, mode="lines",
                line={"color": color, "width": 2.4, "dash": dash},
                name=name, legendgroup=name, showlegend=show_legend,
                hoverinfo="text", text=texts and [texts[0]] * len(xs) or None,
                customdata=custom and [custom[0]] * len(xs) or None,
            )
        )

    def label_for(e: dict[str, Any]) -> str:
        parts = []
        if e.get("count"):
            parts.append(f"{e['count']} transfer(s)")
        if e.get("total_amount") is not None:
            parts.append(f"{float(e['total_amount']):,.2f}")
        if e.get("last_ts"):
            parts.append(str(e["last_ts"]))
        return " · ".join(parts)

    add_edges(
        [e for e in edges if e.get("active") is not False
         and (e["src"], e["dst"]) not in corroborated
         and (e["src"], e["dst"]) not in structural],
        name="active routing (TRANSFERRED_TO)", color=_COLORS["active"], dash="solid",
    )
    add_edges(
        [e for e in edges if e.get("active") is False],
        name="deactivated routing", color=_COLORS["inactive"], dash="dash",
    )
    add_edges(
        [{"src": s, "dst": d, "label": "circulation (corroborated)"}
         for (s, d) in sorted(corroborated)],
        name="corroborated circulation", color=_COLORS["corroborated"], dash="solid",
    )
    add_edges(
        [{"src": s, "dst": d, "label": "structure only (not circulation)"}
         for (s, d) in sorted(structural)],
        name="structural cycle only", color=_COLORS["structural"], dash="dot",
    )

    # ---- nodes -----------------------------------------------------------
    def bucket(account: str) -> str:
        if account == focal_account_id:
            return "focal"
        if account in primary:
            return "primary"
        return "account"

    for key, name, color in (
        ("focal", "alerted account", _COLORS["focal"]),
        ("primary", "implicated entity", _COLORS["primary"]),
        ("account", "account", _COLORS["account"]),
    ):
        group = [a for a in accounts if bucket(a) == key]
        if not group:
            continue
        fig.add_trace(
            go.Scatter(
                x=[pos[a][0] for a in group],
                y=[pos[a][1] for a in group],
                mode="markers+text",
                marker={
                    "size": 26 if key == "focal" else 18,
                    "color": color,
                    "line": {"width": 1.6, "color": _COLORS["font"]},
                },
                text=group,
                textposition="top center",
                textfont={"size": 10, "color": _COLORS["font"]},
                name=name, legendgroup=name,
                customdata=[[["node", a]] for a in group],
                hovertext=[f"account {a}" for a in group],
                hoverinfo="text",
            )
        )

    fig.update_layout(
        height=height,
        margin={"l": 8, "r": 8, "t": 8, "b": 8},
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor=_COLORS["bg"],
        font={"color": _COLORS["font"], "size": 12},
        showlegend=True,
        legend={
            "orientation": "h", "yanchor": "bottom", "y": -0.16,
            "x": 0, "bgcolor": "rgba(0,0,0,0)",
        },
        xaxis={"visible": False}, yaxis={"visible": False},
        dragmode="pan",
        clickmode="event+select",
        hovermode="closest",
    )
    return fig


def selected_from_event(event: Any) -> dict[str, Any] | None:
    """Map a ``st.plotly_chart(on_select=...)`` result to a real record.

    Returns ``{"kind": "node", "account_id": ...}`` or
    ``{"kind": "edge", "src": ..., "dst": ...}``, or ``None`` when nothing is
    selected. Tolerant of the several shapes Streamlit/Plotly return.
    """
    if not event:
        return None
    selection = event.get("selection") if isinstance(event, dict) else None
    points = None
    if isinstance(selection, dict):
        points = selection.get("points")
    if points is None and isinstance(event, dict):
        points = event.get("points")
    if not points:
        return None
    point = points[0]
    custom = point.get("customdata") if isinstance(point, dict) else None
    # A node selection may arrive as the flat ["node", id] or nested [[...]].
    if isinstance(custom, list) and len(custom) == 1 and isinstance(custom[0], list):
        custom = custom[0]
    if not isinstance(custom, (list, tuple)) or not custom:
        return None
    kind = custom[0]
    if kind == "node" and len(custom) >= 2:
        return {"kind": "node", "account_id": custom[1]}
    if kind == "edge" and len(custom) >= 3:
        return {"kind": "edge", "src": custom[1], "dst": custom[2]}
    return None


def node_details(account_id: str, *, edges: list[dict[str, Any]],
                 transactions: list[dict[str, Any]] | None = None,
                 cases: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Real relationships of one account, from the returned rows only."""
    outgoing = [e for e in edges if e.get("src") == account_id]
    incoming = [e for e in edges if e.get("dst") == account_id]
    related_txns = [
        t for t in (transactions or [])
        if t.get("src") == account_id or t.get("dst") == account_id
    ]
    related_cases = [
        c for c in (cases or [])
        if account_id in (c.get("entity_ids") or []) or c.get("account_id") == account_id
    ]
    return {
        "account_id": account_id,
        "out_degree": len(outgoing),
        "in_degree": len(incoming),
        "outgoing": sorted(outgoing, key=lambda e: -float(e.get("total_amount") or 0)),
        "incoming": sorted(incoming, key=lambda e: -float(e.get("total_amount") or 0)),
        "transactions": related_txns,
        "cases": related_cases,
    }


def edge_details(src: str, dst: str, *, edges: list[dict[str, Any]],
                 transactions: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Real evidence behind one directed edge."""
    edge = next(
        (e for e in edges if e.get("src") == src and e.get("dst") == dst), None
    )
    txns = [
        t for t in (transactions or [])
        if t.get("src") == src and t.get("dst") == dst
    ]
    return {
        "src": src, "dst": dst,
        "edge": edge,
        "transactions": txns,
        "has_aggregate": edge is not None,
        "has_transactions": bool(txns),
    }